package neatimplementation;

public interface FitnessFunction
{
    public double fitness(Genome g);
}
