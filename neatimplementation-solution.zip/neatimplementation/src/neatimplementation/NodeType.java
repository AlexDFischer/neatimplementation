package neatimplementation;
public enum NodeType
{
    INPUT, HIDDEN, BIAS, OUTPUT
}
